//! # Index Parsing Dispatcher
//!
//! This module acts as the main entry point for parsing the key and record
//! block indexes of an MDict file. It dispatches to the appropriate
//! version-specific parser based on the `MdictVersion`.

use crate::mdict::types::error::Result;
use crate::mdict::types::models::{
    BlockMeta, EncryptionFlags, MasterKey, MdictEncoding, MdictVersion,
};
use std::fs::File;

pub mod common;
pub mod v1v2;
pub mod v3;

/// The result of parsing a dictionary's index.
///
/// This tuple contains:
/// 1.  A `Vec<BlockMeta>` for the key blocks.
/// 2.  A `Vec<BlockMeta>` for the record blocks.
/// 3.  A `u64` representing the total decompressed size of all record blocks.
/// 4.  A `u64` representing the total number of entries in the dictionary.
pub type ParseResult = (Vec<BlockMeta>, Vec<BlockMeta>, u64, u64);

/// Parses the key and record block metadata based on the MDict version.
///
/// This function reads the index information from the file and returns the
/// metadata for both key and record blocks, along with the total decompressed
/// size of all record blocks and the total number of entries.
pub fn parse(
    file: &mut File,
    version: MdictVersion,
    encoding: MdictEncoding,
    encryption_flags: EncryptionFlags,
    master_key: MasterKey,
) -> Result<ParseResult> {
    match version {
        MdictVersion::V3 => v3::parse(file, version, encoding, master_key),
        MdictVersion::V1 | MdictVersion::V2 => {
            v1v2::parse(file, version, encoding, encryption_flags, master_key)
        }
    }
}
